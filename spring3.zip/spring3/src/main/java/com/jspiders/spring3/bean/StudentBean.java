package com.jspiders.spring3.bean;

import lombok.Data;

@Data
public class StudentBean {
	
	private int Id;
	private String Name;
	private String Email;
	private long Contact;
	private String City;

}
